import "./css/style.css";
import "./js/component/app-bar.js";
import main from "./js/view/main.js";
import "regenerator-runtime";
document.addEventListener("DOMContentLoaded", main);